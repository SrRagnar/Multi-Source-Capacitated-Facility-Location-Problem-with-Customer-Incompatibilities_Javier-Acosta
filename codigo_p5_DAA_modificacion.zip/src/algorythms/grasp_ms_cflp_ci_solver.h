// University of La Laguna
// School of Engineering and Technology
// Bachelor's Degree in Computer Engineering
// Subject: Design and Analysis of Algorithms
// Course: 3rd
// Practice 6: Multi-Source Capacitated Facility Location Problem with Customer Incompatibilities
// Author: Javier Acosta Portocarrero
// Date: 04/04/2026
// File grasp-ms-cflp-ci-solver.h: declaration file.
// Contains the declaration of the GraspMsCflpCiSolver class.

#ifndef GRAASP_MS_CFLP_CI_SOLVER_H_
#define GRAASP_MS_CFLP_CI_SOLVER_H_

#include "grasp_algorythm.h"
#include "../instances/ms_cflp_ci_instance.h"
#include "../solutions/ms_cflp_ci_solution.h"
#include "../explorers/ms_cflp_ci_neighboorhod_explorer.h"

/**
 * @class GraspMsCflpCiSolver
 *
 * @brief Class that implements the GRASP metaheuristic to solve the MS-CFLP-CI problem.
 */
class GraspMsCflpCiSolver : public GraspAlgorythm {
 public:
  GraspMsCflpCiSolver(unsigned cardinality = 1, std::vector<MsCflpCiNeighboorhodExplorer*> explorers = {}) : 
                      lcr_cardinality_{cardinality}, neighboorhod_explorers_{explorers} {}
  ~GraspMsCflpCiSolver() override = default;
 protected:
  void Preprocess(Instance* input) override;
  Solution* ConstructSolution(Instance* input) override;
  virtual Solution* Postprocess(Solution* solution) override = 0;
  void UpdateBest(Solution* current, Solution*& best) override;
  virtual bool StopCriterion() override;
  const std::vector<MsCflpCiNeighboorhodExplorer*>& GetNeighborhoodExplorers() const { return neighboorhod_explorers_;}
  double GetAmountTolerance() const { return kAmountTolerance_;}
  double GetImprovementTolerance() const { return kImprovementTolerance_;}
  
 private:
  unsigned current_grasp_iteration_ = 0;
  unsigned max_grasp_iterations_ = 1;
  unsigned lcr_cardinality_ = 1;
  std::vector<MsCflpCiNeighboorhodExplorer*> neighboorhod_explorers_;
  static constexpr double kAmountTolerance_ = 1e-8;
  static constexpr double kImprovementTolerance_ = 1e-8;

  unsigned FindSlackValue(const MsCflpCiInstance& instance) const;
  std::vector<int> GetSortedFacilitiesByScore(const MsCflpCiInstance& instance, const MsCflpCiSolution& solution) const;
  std::vector<int> GetSortedFacilitiesByCostForCustomer(const MsCflpCiSolution& solution, int customer_id) const;

  MsCflpCiSolution* ExploreIncompatibilitiesRemoveNeighborhood(MsCflpCiSolution* solution) const;
};

#endif