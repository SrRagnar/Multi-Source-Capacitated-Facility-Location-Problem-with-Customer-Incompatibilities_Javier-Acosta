// University of La Laguna
// School of Engineering and Technology
// Bachelor's Degree in Computer Engineering
// Subject: Design and Analysis of Algorithms
// Course: 3rd
// Practice 6: Multi-Source Capacitated Facility Location Problem with Customer
// Incompatibilities
// Author: Javier Acosta Portocarrero
// Date: 10/04/2026
// File ms_cflp_ci_shift_explorer.h: declaration file.
// Contains the declaration of the MsCflpCiShiftExplorer class.

#ifndef MS_CFLP_CI_SHIFT_EXPLORER_H_
#define MS_CFLP_CI_SHIFT_EXPLORER_H_

#include <vector>

#include "ms_cflp_ci_neighboorhod_explorer.h"

class MsCflpCiShiftExplorer : public MsCflpCiNeighboorhodExplorer {
 public:
  MsCflpCiShiftExplorer() = default;
  ~MsCflpCiShiftExplorer() override = default;

  MsCflpCiSolution* Explore(const MsCflpCiSolution* solution, double amount_tol, double improvement_tol) const override;
 private:
  std::vector<int> GetSortedFacilitiesByCostForCustomer(const MsCflpCiSolution& solution, 
                                                        int customer_id, double amount_tol, 
                                                        double improvement_tol) const;
  bool CanShiftFlow(const MsCflpCiSolution& solution, 
                    int customer_id, int source_facility, int target_facility, double amount,
                    double amount_tol, double improvement_tol) const;

  double EvaluateShiftDelta(const MsCflpCiSolution& solution, 
                            int customer_id, int source_facility, int target_facility, double amount,
                            double amount_tol, double improvement_tol) const;

  bool ShiftFlow(MsCflpCiSolution& solution, 
                 int customer_id, int source_facility, int target_facility, double amount,
                 double amount_tol, double improvement_tol) const;
};

#endif